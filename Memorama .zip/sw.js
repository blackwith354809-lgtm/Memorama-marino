function iniciarJuego() {
  detenerTemporizador();
  tablero.innerHTML = '';
  cartas = [];
  primera = segunda = null;
  bloqueo = false;
  movimientos = 0;
  paresEncontrados = 0;
  segundosRestantes = TIEMPO_INICIAL;
  cronometroIniciado = false;

  // 👥 Preparar jugadores
  recolectarNombres();
  jugadores.forEach(j => j.pares = 0);
  turnoActual = 0;
  renderPanelJugadores();

  const cfg = DIFICULTADES[dificultadActual];
  totalPares = cfg.pares;

  elMovs.textContent = 0;
  elPares.textContent = `0/${totalPares}`;
  elTiempo.textContent = segundosRestantes;
  elTiempo.classList.remove('tiempo-alerta');
  tablero.style.gridTemplateColumns = `repeat(${cfg.columnas}, 1fr)`;

  const elegidos = barajar([...SIMBOLOS]).slice(0, totalPares);
  const valores  = barajar([...elegidos, ...elegidos]);

  valores.forEach((sim, indice) => {
    const c = document.createElement('div');
    c.classList.add('carta');
    c.dataset.valor = sim;
    c.innerHTML = `
      <div class="cara reverso">${indice + 1}</div>
      <div class="cara frente">${sim}</div>
    `;
    c.addEventListener('click', () => voltear(c));
    tablero.appendChild(c);
    cartas.push(c);
  });

  mostrarPantalla('juego');
}

function renderPanelJugadores() {
  const cont = document.getElementById('panelJugadores');
  if (numJugadores <= 1) { cont.style.display = 'none'; return; }
  cont.style.display = 'flex';
  cont.innerHTML = jugadores.map((j, i) => `
    <div class="jugador-chip ${i === turnoActual ? 'activo' : ''}">
      ${j.nombre} · <span class="puntos">${j.pares}</span>
    </div>
  `).join('');
}

function voltear(carta) {
  if (bloqueo) return;
  if (carta.classList.contains('volteada')) return;
  if (carta.classList.contains('encontrada')) return;

  if (!cronometroIniciado) {
    cronometroIniciado = true;
    iniciarTemporizador();
  }

  carta.classList.add('volteada');
  if (!primera) { primera = carta; return; }

  segunda = carta;
  movimientos++;
  elMovs.textContent = movimientos;
  bloqueo = true;

  if (primera.dataset.valor === segunda.dataset.valor) {
    primera.classList.add('encontrada');
    segunda.classList.add('encontrada');
    paresEncontrados++;

    // 👥 Sumar al jugador en turno (si hay multijugador)
    if (numJugadores > 1) jugadores[turnoActual].pares++;
    renderPanelJugadores();

    elPares.textContent = `${paresEncontrados}/${totalPares}`;
    resetTurno();

    // 👥 Acierto = repite turno (no cambiamos turnoActual)
    if (paresEncontrados === totalPares) setTimeout(mostrarVictoria, 700);
  } else {
    // 👥 Fallo = pasa al siguiente jugador
    setTimeout(() => {
      primera.classList.remove('volteada');
      segunda.classList.remove('volteada');
      resetTurno();
      if (numJugadores > 1) {
        turnoActual = (turnoActual + 1) % numJugadores;
        renderPanelJugadores();
      }
    }, 1000);
  }
}

function resetTurno() { primera = null; segunda = null; bloqueo = false; }